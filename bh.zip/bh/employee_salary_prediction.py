import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import LabelEncoder
import pyexcel_ods3

# 1. Load Dataset from .ods file
ods_data = pyexcel_ods3.get_data('Employee_Salary_Dataset.ods')
sheet = ods_data['Sheet1']
header = sheet[0]
data = sheet[1:]
df = pd.DataFrame(data, columns=header)
df = df.dropna().reset_index(drop=True)

# Convert columns to appropriate types
for col in ['ID', 'Experience_Years', 'Age', 'Salary']:
    df[col] = pd.to_numeric(df[col], errors='coerce')
df['Gender'] = df['Gender'].astype(str)

# 2. Data Exploration - Beautiful Plots
plt.figure(figsize=(8, 5))
sns.histplot(df['Salary'], kde=True, color='skyblue')
plt.title('Salary Distribution', fontsize=16)
plt.xlabel('Salary')
plt.ylabel('Frequency')
plt.tight_layout()
plt.savefig('salary_distribution.png')
plt.show()

plt.figure(figsize=(8, 5))
sns.scatterplot(x='Experience_Years', y='Salary', hue='Gender', data=df, palette='Set2', s=100)
plt.title('Experience vs Salary by Gender', fontsize=16)
plt.xlabel('Years of Experience')
plt.ylabel('Salary')
plt.tight_layout()
plt.savefig('exp_vs_salary.png')
plt.show()

# Correlation heatmap
plt.figure(figsize=(6, 4))
sns.heatmap(df[['Experience_Years', 'Age', 'Salary']].corr(), annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Correlation Heatmap', fontsize=14)
plt.tight_layout()
plt.savefig('correlation_heatmap.png')
plt.show()

# 3. Encode categorical variables
le = LabelEncoder()
df['Gender_encoded'] = le.fit_transform(df['Gender'])

# 4. Feature Selection
X = df[['Experience_Years', 'Age', 'Gender_encoded']]
y = df['Salary']

# 5. Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 6. Model Training
model = LinearRegression()
model.fit(X_train, y_train)

# 7. Prediction
y_pred = model.predict(X_test)

# 8. Evaluation
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f'\nMean Squared Error: {mse:.2f}')
print(f'R^2 Score: {r2:.2f}')

# 9. Actual vs Predicted Plot
plt.figure(figsize=(8, 5))
sns.scatterplot(x=y_test, y=y_pred, color='purple', s=100)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
plt.title('Actual vs Predicted Salary', fontsize=16)
plt.xlabel('Actual Salary')
plt.ylabel('Predicted Salary')
plt.tight_layout()
plt.savefig('actual_vs_predicted.png')
plt.show()

# 10. Residuals Plot
residuals = y_test - y_pred
plt.figure(figsize=(8, 5))
sns.histplot(residuals, kde=True, color='orange')
plt.title('Residuals Distribution', fontsize=16)
plt.xlabel('Residuals')
plt.ylabel('Frequency')
plt.tight_layout()
plt.savefig('residuals_distribution.png')
plt.show()

# 11. Predicting for a new value
sample = pd.DataFrame({'Experience_Years': [5], 'Age': [28], 'Gender_encoded': [le.transform(['Female'])[0]]})
predicted_salary = model.predict(sample)[0]
print(f'\nPredicted salary for 5 years experience, 28 years old, Female: {predicted_salary:.2f}') 